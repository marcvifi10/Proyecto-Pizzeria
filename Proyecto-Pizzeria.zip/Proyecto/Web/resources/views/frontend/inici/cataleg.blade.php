@extends('layouts.app')

@extends('frontend.inici.menu')