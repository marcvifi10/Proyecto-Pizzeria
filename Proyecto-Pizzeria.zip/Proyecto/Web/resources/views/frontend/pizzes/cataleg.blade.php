@extends('layouts.app')

@extends('frontend.pizzes.menu')