@extends('layouts.app')

@extends('frontend.menus.menu')