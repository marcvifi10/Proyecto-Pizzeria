<div class="container" id="fons">
    <br><br>
	<br>
	<div id="container color">
		<!-- Creem un 'div', per al contingut de la pàgina -->
		<div id="fons2" class="container content inici" style="min-height: 480px;">
			<!-- Deixem una fila buida, perquè hi hagi separació entre el menú i el contingut de la pàgina -->
			<div class="row">
				<div class="col-xs-12">
					<ol class="bredcrumb pull-left"></ol>
				</div>
			</div>
			<!-- Creem una fila, que servirà per mostrar les diferents opcions que hi han per cada apartat del menú -->
			<!-- Al inici, per defecte, mostrarà un missatge de benvinguda -->
			<div class="row">
				<!-- Determinem la posició del menú -->
				<div class="col-xs-12 col-md-2 col-sm-2 col-lg-3">
					<font size="3">
						<strong>Secció de incial</strong>
					</font>
				</div>
			</div>
		</div> 
	</div>
	<br><br>
	<br><br>
</div>
<br><br>			