@extends('layouts.app')

@extends('frontend.drinks.menu')