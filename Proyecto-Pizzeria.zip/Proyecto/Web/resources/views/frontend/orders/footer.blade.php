<footer class="footer-color" style="bottom: 0">
	<br>
	<div class="row">
		<div class="col-xl-offset-1 col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-xs-offset-4">
			<img src="../images/logo.png" width="170px" height="60px">
		</div>
		<div class="col-xl-offset-3 col-lg-offset-3 col-md-offset-2 col-sm-offset-2 col-xs-offset-4">
			<font size="4">© 2019 Majovi's Pizza</font>
		</div>
		<div class="col-xl-offset-3 col-lg-offset-3 col-md-offset-2 col-sm-offset-2 col-xs-offset-5">
			<font size="4">972 905 905</font>
		</div>
	</div>
	<br><br>
</footer>