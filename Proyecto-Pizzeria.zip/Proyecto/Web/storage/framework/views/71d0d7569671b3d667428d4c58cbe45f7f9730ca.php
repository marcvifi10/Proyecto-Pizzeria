<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.orders")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/table_row_link.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
	<div class="col-sm-12">
		<h3><?php echo e(trans("web.orders")); ?></h3>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th><?php echo e(trans("web.client")); ?></th>
					<th><?php echo e(trans("web.address")); ?></th>
					<th><?php echo e(trans("web.state")); ?></th>
					<th><?php echo e(trans("web.created_at")); ?></th>
				</tr>
			</thead>
			<?php $__empty_1 = true; $__currentLoopData = $franchise->orders()->orderby("created_at", "desc")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr class="tableRowLink" data-href="<?php echo e(route('franchise.orderDetails', $order->id)); ?>">
					<td><?php echo e($order->user->name); ?></td>
					<td><?php echo e($order->user->address); ?></td>
					<td><?php echo e($order->orderstate->name); ?></td>
					<td><?php echo e($order->created_at); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td colspan=4><?php echo e(trans("web.orders_not_found")); ?></td>
				</tr>
			<?php endif; ?>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/franchises/orders.blade.php ENDPATH**/ ?>