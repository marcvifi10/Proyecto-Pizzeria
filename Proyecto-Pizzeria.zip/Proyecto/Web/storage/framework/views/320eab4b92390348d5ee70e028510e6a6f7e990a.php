<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.order_details")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
	<?php if(!$order): ?>
		<p><?php echo e(trans("web.orders_not_found")); ?></p>
	<?php else: ?>
		<div class="col-sm-12">
			<h3><?php echo e(trans("web.order_details")); ?></h3>
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<th class="w-25"><?php echo e(trans("web.client")); ?></th>
					<td><?php echo e($order->user->name); ?></td>
				</tr>
				<tr>
					<th class="w-25"><?php echo e(trans("web.address")); ?></th>
					<td><?php echo e($order->user->address); ?></td>
				</tr>
				<tr>
					<th class="w-25"><?php echo e(trans("web.state")); ?></th>
					<td><?php echo e($order->orderstate->name); ?></td>
				</tr>
				<tr>
					<th class="w-25"><?php echo e(trans("web.created_at")); ?></th>
					<td><?php echo e($order->created_at); ?></td>
				</tr>
			</table>
		</div>
		<div class="col-sm-12">
			<h3><?php echo e(trans("web.state_history")); ?></h3>
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<th><?php echo e(trans("web.state")); ?></th>
					<th><?php echo e(trans("web.date")); ?></th>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $order->orderstate_history()->orderBy("created_at", "desc")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><?php echo e($order_state->ordestate->name); ?></td>
						<td><?php echo e($order_state->created_at); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<td colspan=2><?php echo e(trans("web.order_lines_not_found")); ?></td>
				<?php endif; ?>
			</table>
		</div>
		<div class="col-sm-12">
			<h3><?php echo e(trans("web.order_lines")); ?></h3>
			<table class="table table-striped table-bordered table-hover">
				<tr>
					<th><?php echo e(trans("web.quantity")); ?></th>
					<th><?php echo e(trans("web.product")); ?></th>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $order->order_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td class="w-25"><?php echo e($order_line->quantify); ?></td>
						<td><?php echo e($order_line->product->name); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<td colspan=2><?php echo e(trans("web.order_lines_not_found")); ?></td>
				<?php endif; ?>
			</table>
		</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/franchises/order_details.blade.php ENDPATH**/ ?>