<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.ingredients")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/confirm_delete.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
	<div class="col-sm-12">
		<a href="<?php echo e(route('admin.ingredients.create')); ?>" class="btn btn-primary" role="button">
			<?php echo e(trans("web.create")); ?>

		</a>
	</div>
	<div class="col-sm-12">
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th><?php echo e(trans("web.name")); ?></th>
					<th><?php echo e(trans("web.category")); ?></th>
					<th><?php echo e(trans("web.description")); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td>
                        <a href="<?php echo e(route('admin.ingredients.show', $ingredient->id)); ?>">
                            <?php echo e($ingredient->name); ?>

                        </a>
                    </td>
					<td>
                        <?php echo e($ingredient->ingredientcategory->name); ?>

                    </td>
					<td class="w-50"><?php echo e($ingredient->description); ?></td>
					<td>
                        <a href="<?php echo e(route('admin.ingredients.edit', $ingredient->id)); ?>" class="btn btn-primary" role="button">
                            <?php echo e(trans("web.edit")); ?>

                        </a>
                    </td>
                    <td>
						<?php echo e(Form::open(['route' => ['admin.ingredients.destroy', $ingredient->id],
							'method' => 'DELETE', "class" => "deleteForm"])); ?>

						<?php echo e(Form::submit(trans("web.delete"), ["class" => "btn btn-danger",
							"data-text" => trans("web.confirm_delete")])); ?>

                        <?php echo e(Form::close()); ?>

                    </td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td colspan=3><?php echo e(trans("web.ingredients_not_found")); ?></td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/ingredients/index.blade.php ENDPATH**/ ?>