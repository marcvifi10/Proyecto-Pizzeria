<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.products")); ?>

<?php $__env->stopSection(); ?>

<?php
	if (isset($_GET["search"]) && !empty($_GET["search"])) {
		$products = $products->reject(function ($product) {
                        return stripos($product->name, $_GET["search"]) === false;
                    });
	}
?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('js/confirm_delete.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/update_content_search.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("style"); ?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css"
	integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ"
	crossorigin="anonymous">
<link href="<?php echo e(asset('css/backend_index.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-2">
            <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary" role="button">
                <span class="buttonText"><?php echo e(trans("web.create")); ?></span>
            </a>
        </div>
        <div class="col-sm-10">
            <?php echo $__env->make("partials.backend_searchbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="row" id="content">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th><?php echo e(trans("web.name")); ?></th>
						<th><?php echo e(trans("web.price")); ?></th>
						<th><?php echo e(trans("web.category")); ?></th>
						<th><?php echo e(trans("web.description")); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td>
							<a href="<?php echo e(route('admin.products.show', $product->id)); ?>">
								<?php echo e($product->name); ?>

							</a>
						</td>
						<td><?php echo e($product->price); ?></td>
						<td><?php echo e($product->productcategory->name); ?></td>
						<td class="w-50"><?php echo e($product->description); ?></td>
						<td>
							<a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-primary" role="button">
								<?php echo e(trans("web.edit")); ?>

							</a>
						</td>
						<td>
							<?php echo e(Form::open(['route' => ['admin.products.destroy', $product->id],
								'method' => 'DELETE', "class" => "deleteForm"])); ?>

							<?php echo e(Form::submit(trans("web.delete"), ["class" => "btn btn-danger",
								"data-text" => trans("web.confirm_delete")])); ?>

							<?php echo e(Form::close()); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan=4><?php echo e(trans("web.products_not_found")); ?></td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/products/index.blade.php ENDPATH**/ ?>