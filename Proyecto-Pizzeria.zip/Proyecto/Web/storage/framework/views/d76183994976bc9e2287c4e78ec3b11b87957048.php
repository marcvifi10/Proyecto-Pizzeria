<?php $__env->startSection("title"); ?>
<?php echo e(trans("web.edit")); ?> <?php echo e(strtolower(trans("web.franchise"))); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <?php echo e(Form::open(['route' => ['admin.franchises.update', $franchise->id], 'method' => 'PUT'])); ?>

    <div class="form-group">
        <?php echo e(Form::label('name', trans("web.name").":")); ?>

        <?php echo e(Form::text('name', $franchise->name, ["class" => "form-control"])); ?>

        <?php
            if ($errors->has('name')) {
                echo "<div style='color: #ff0000'>".$errors->first('name')."</div>";
            }
        ?>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', trans("web.email").":")); ?>

        <?php echo e(Form::email('email', $franchise->email, ["class" => "form-control"])); ?>

        <?php
            if ($errors->has('email')) {
                echo "<div style='color: #ff0000'>".$errors->first('email')."</div>";
            }
        ?>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('address', trans("web.address").":")); ?>

        <?php echo e(Form::text('address', $franchise->address, ["class" => "form-control"])); ?>

        <?php
            if ($errors->has('address')) {
                echo "<div style='color: #ff0000'>".$errors->first('address')."</div>";
            }
        ?>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('phone', trans("web.phone").":")); ?>

        <?php echo e(Form::text('phone', $franchise->phone, ["class" => "form-control"])); ?>

        <?php
            if ($errors->has('phone')) {
                echo "<div style='color: #ff0000'>".$errors->first('phone')."</div>";
            }
        ?>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('coordinates', trans("web.coordinates").":")); ?>

        <?php echo e(Form::text('coordinates', $franchise->coordinates, ["class" => "form-control"])); ?>

        <?php
            if ($errors->has('coordinates')) {
                echo "<div style='color: #ff0000'>".$errors->first('coordinates')."</div>";
            }
        ?>
    </div>

    <div class="form-group">
        <?php echo e(Form::submit(trans("web.submit"), ["class" => "btn btn-primary"])); ?>

	</div>

	<div class="form-group">
		<a href="<?php echo e(route('admin.franchises.index')); ?>" class="btn btn-danger" role="button">
			<?php echo e(trans("web.cancel")); ?>

		</a>
	</div>
    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Pizzeria\resources\views/backend/franchises/edit.blade.php ENDPATH**/ ?>