Install packages with:
composer install

Change .env config to connect to local database

Generate application key with:
php artisan key:generate

Create local database

Create database tables and data with:
php artisan migrate --seed