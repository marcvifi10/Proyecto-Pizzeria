function cambiarClase(){
    let siteNav = document.getElementById('site-nav');
        siteNav.classList.toggle('site-nav-open');
    let menuOpen = document.getElementById('menu-toggle');
        menuOpen.classList.toggle('menu-open');    
        
}

function inici()
{

    document.getElementById('inici').style.color="blue";
    document.getElementById('pizzes').style.color="black";
    document.getElementById('begudes').style.color="black";
    document.getElementById('menus').style.color="black";
    document.getElementById('postres').style.color="black";
    document.getElementById('login').style.color="black";
    document.getElementById('registre').style.color="black";

}

function pizzes()
{

    document.getElementById('inici').style.color="black";
    document.getElementById('pizzes').style.color="blue";
    document.getElementById('begudes').style.color="black";
    document.getElementById('menus').style.color="black";
    document.getElementById('postres').style.color="black";
    document.getElementById('login').style.color="black";
    document.getElementById('registre').style.color="black";

}

function begudes()
{

    document.getElementById('inici').style.color="black";
    document.getElementById('pizzes').style.color="black";
    document.getElementById('begudes').style.color="blue";
    document.getElementById('menus').style.color="black";
    document.getElementById('postres').style.color="black";
    document.getElementById('login').style.color="black";
    document.getElementById('registre').style.color="black";

}

function menus()
{

    document.getElementById('inici').style.color="black";
    document.getElementById('pizzes').style.color="black";
    document.getElementById('begudes').style.color="black";
    document.getElementById('menus').style.color="blue";
    document.getElementById('postres').style.color="black";
    document.getElementById('login').style.color="black";
    document.getElementById('registre').style.color="black";

}

function postres()
{

    document.getElementById('inici').style.color="black";
    document.getElementById('pizzes').style.color="black";
    document.getElementById('begudes').style.color="black";
    document.getElementById('menus').style.color="black";
    document.getElementById('postres').style.color="blue";
    document.getElementById('login').style.color="black";
    document.getElementById('registre').style.color="black";

}

function login()
{

    document.getElementById('inici').style.color="black";
    document.getElementById('pizzes').style.color="black";
    document.getElementById('begudes').style.color="black";
    document.getElementById('menus').style.color="black";
    document.getElementById('postres').style.color="black";
    document.getElementById('login').style.color="blue";
    document.getElementById('registre').style.color="black";

}

function registre()
{

    document.getElementById('inici').style.color="black";
    document.getElementById('pizzes').style.color="black";
    document.getElementById('begudes').style.color="black";
    document.getElementById('menus').style.color="black";
    document.getElementById('postres').style.color="black";
    document.getElementById('login').style.color="black";
    document.getElementById('registre').style.color="blue";

}